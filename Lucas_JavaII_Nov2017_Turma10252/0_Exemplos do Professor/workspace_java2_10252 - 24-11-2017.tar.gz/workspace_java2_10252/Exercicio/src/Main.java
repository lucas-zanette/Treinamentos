import java.io.FileNotFoundException;
import java.util.Formatter;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		String[][] s = new String[3][3];
		
		s[0][0] = "Josenaldo";
		s[0][1] = "Rua J";
		s[0][2] = "Marcolésia";

		s[1][0] = "Vandercreison";
		s[1][1] = "Rua V";
		s[1][2] = "Martolínea";
		
		s[2][0] = "João";
		s[2][1] = "Rua J";
		s[2][2] = "Joana";

		Formatter f = new Formatter("/home/aluno/exercicio.txt");
		for (int i = 0; i < 3; i++) {
			f.format("Nome: %s\nEndereço: %s\nMãe: %s\n---------------------\n", s[i][0], s[i][1], s[i][2]);
		}
		f.close();
	}

}
