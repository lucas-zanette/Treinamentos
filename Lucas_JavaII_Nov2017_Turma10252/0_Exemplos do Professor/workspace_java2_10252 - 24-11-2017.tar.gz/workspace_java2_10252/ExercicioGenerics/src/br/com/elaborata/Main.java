package br.com.elaborata;

import java.io.FileNotFoundException;

public class Main {

	public static void main(String[] args) {
		GeraLog<Game> lg = new GeraLog<Game>();
		try {
			lg.abrir("/home/aluno/logGame.log");
		} catch (FileNotFoundException e) {
			System.out.println("Não foi possível criar o arquivo de log.");
			return;
		}
		
		Game g = new Game(1, "Road Rash", "Corrida");
		lg.gravar(g);
		g = new Game(2, "Counter Strike", "Tiro");
		lg.gravar(g);
		g = new Game(3, "Donkey Kong", "Aventura");
		lg.gravar(g);
		g = new Game(4, "FIFA", "Esporte");
		lg.gravar(g);

		lg.fechar();
		
		GeraLog<Filme> lf = new GeraLog<Filme>();

		try {
			lf.abrir("/home/aluno/logFilme.log");
		} catch (FileNotFoundException e) {
			System.out.println("Não foi possível criar o arquivo de log.");
			return;
		}
		
		Filme f = new Filme(1, "Alien", "Ridley Scott");
		lf.gravar(f);
		f = new Filme(2, "Star Wars", "George Lucas");
		lf.gravar(f);
		f = new Filme(3, "E.T.", "Steve Spilberg");
		lf.gravar(f);
		
		lf.fechar();
	}

}
