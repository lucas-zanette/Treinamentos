package br.com.elaborata;

public class ThreadExemplo extends Thread {
	
	int num;
	
	public ThreadExemplo(int num) {
		this.num = num;
	}
	
	public void run() {
		for (long i = 0; i < 9999999999l; i++) {
		}
		for (long i = 0; i < 9999999999l; i++) {
		}
		for (long i = 0; i < 9999999999l; i++) {
		}
		for (long i = 0; i < 9999999999l; i++) {
		}
		for (long i = 0; i < 9999999999l; i++) {
		}
		for (long i = 0; i < 9999999999l; i++) {
		}
		
		System.out.println("Terminou a thread " + num);
	}
}
