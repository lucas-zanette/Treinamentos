package br.com.elaborata;

public class Main {

	public static void main(String[] args) {
		ThreadExemplo th1 = new ThreadExemplo(1);
		ThreadExemplo th2 = new ThreadExemplo(2);
		ThreadExemplo th3 = new ThreadExemplo(3);
		ThreadExemplo th4 = new ThreadExemplo(4);
		ThreadExemplo th5 = new ThreadExemplo(5);

		th1.start();
		th2.start();
		th3.start();
		th4.start();
		th5.start();
		
		System.out.println("A main terminou.");
	}

}
