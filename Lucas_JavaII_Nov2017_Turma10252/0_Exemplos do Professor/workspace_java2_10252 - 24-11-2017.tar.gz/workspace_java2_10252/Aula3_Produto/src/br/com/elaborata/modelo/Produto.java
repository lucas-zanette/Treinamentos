package br.com.elaborata.modelo;

import java.io.Serializable;

public class Produto implements Serializable {

	private int codigo;
	private String descricao;
	private int qtd;
	
	public Produto(int codigo, String descricao, int qtd) throws Exception {
		super();
		setCodigo(codigo);
		setDescricao(descricao);
		setQtd(qtd);
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) throws Exception {
		if (codigo < 0) 
			throw new Exception("O código não pode ser negativo.");
		this.codigo = codigo;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) throws Exception {
		if ( (descricao == null) || (descricao.equals("")) )
			throw new Exception("A descrição não pode ser vazia.");
		this.descricao = descricao;
	}
	public int getQtd() {
		return qtd;
	}
	public void setQtd(int qtd) throws Exception {
		if (qtd < 0)
			throw new Exception("A quantidade não pode ser negativa.");
		this.qtd = qtd;
	}
	
}
