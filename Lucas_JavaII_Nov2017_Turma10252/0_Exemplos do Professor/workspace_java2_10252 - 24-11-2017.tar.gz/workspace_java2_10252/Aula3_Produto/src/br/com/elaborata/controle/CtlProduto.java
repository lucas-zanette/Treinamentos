package br.com.elaborata.controle;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import br.com.elaborata.modelo.Produto;

public class CtlProduto {
	
	private final String caminho = "/home/aluno/Objetos/";
	private File pasta;
	private String[] lst; 
	private int pos = -1;

	public CtlProduto () {
		//Cria um objeto vinculado ao diretório onde estão os arquivos serializados.
		pasta = new File(caminho);

		//Recupera a lista de nome de arquivos que estão gravados na pasta.
		lst = pasta.list();
	}
	
	public int salvar(Produto p, boolean podeSobrescrever) throws Exception {
		//Se não pode sobrescrever...
		if (!podeSobrescrever) {
			//Verificar se o produto já está salvo.
			String nomeArq = caminho + p.getCodigo() + ".obj";
			File f = new File(nomeArq);
			if (f.exists()) {
				//Gerar um erro.
				throw new Exception("O produto já existe.");
			}
		}

		//Gera um código automático, caso necessário.
		if (p.getCodigo() <= 0) {
			p.setCodigo(getProximoCodigo());
		}
		
		//Salva o produto na pasta de objetos.
		serializar(p, Integer.toString(p.getCodigo()));
		
		//Recupera a lista de nome de arquivos que estão gravados na pasta.
		lst = pasta.list();
		
		//Posiciona o cursor de registros, caso necessário.
		if (pos <= -1)
			pos = 0;
		
		//Retorno da função.
		return p.getCodigo();
	}
	
	private int getProximoCodigo() {
		return getMaiorCodigo() + 1;
	}

	private int getMaiorCodigo() {
		int maior = 0;
		
		//Percorro a lista inteira.
		for (String arq : lst) {
			//Corto o nome do arquivo na posição 
			//do ponto, para que eu possa converter
			//o nome do arquivo em número.
			int n = Integer.parseInt(arq.split("\\.")[0]);
			
			//Vejo se o número "n" é o maior até agora.
			if (n > maior)
				maior = n;
		}
		return maior;
	}

	public void excluir(int codigo) {
		//Apago o arquivo.
		File f = new File(caminho + codigo + ".obj");
		f.delete();

		//Recupera a lista de nome de arquivos que estão gravados na pasta.
		lst = pasta.list();

		//Verifica se a posição indicada pela variável ainda é válida.
		if (pos >= lst.length)
			pos--;
	}
	
	public Produto getProx() {
		if (temProx()) {
			pos++;
			return (Produto) desserializar(lst[pos]);
		}
		return null;
	}
	
	public Produto getAnt() {
		if (temAnt()) {
			pos--;
			return (Produto) desserializar(lst[pos]);
		}
		return null;
	}
	
	public Produto getAtual() {
		if (pos > -1)
			return (Produto) desserializar(lst[pos]);
		
		return null;
	}
	
	public boolean temProx() {
		return (pos < (lst.length - 1));
	}
	
	public boolean temAnt() {
		return (pos > 0);
	}
	
	public boolean temAtual() {
		return (pos > -1);
	}

	private void serializar(Serializable obj, String nomeArq) {
		String arquivo = caminho + nomeArq + ".obj";
		
		try {
			ObjectOutputStream output = 
					new ObjectOutputStream(new FileOutputStream(arquivo));
			
			output.writeObject(obj);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private Serializable desserializar(String nomeArq) {
		String arquivo = caminho + nomeArq;

		try {
			ObjectInputStream output = 
					new ObjectInputStream(new FileInputStream(arquivo));
			
			return (Serializable) output.readObject();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
}

















