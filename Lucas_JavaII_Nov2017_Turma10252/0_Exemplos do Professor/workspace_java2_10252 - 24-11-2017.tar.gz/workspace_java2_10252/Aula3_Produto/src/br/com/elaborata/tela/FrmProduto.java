package br.com.elaborata.tela;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import br.com.elaborata.controle.CtlProduto;
import br.com.elaborata.modelo.Produto;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmProduto extends JFrame {

	private CtlProduto ctl = new CtlProduto();
	private String acao = "";
	
	private JPanel contentPane;
	private JTextField txtCodigo;
	private JTextField txtDescricao;
	private JTextField txtQtd;
	private JButton btnSalvar;
	private JButton btnCancelar;
	private JButton btnIncluir;
	private JButton btnAlterar;
	private JButton btnExcluir;
	private JButton btnAnt;
	private JButton btnProx;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmProduto frame = new FrmProduto();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmProduto() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 407, 284);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		
		btnIncluir = new JButton("Incluir");
		btnIncluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				acao = "I";
				preencheCampos(null);
				ativaCampos(true);
			}
		});
		panel.add(btnIncluir);
		
		btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				acao = "A";
				ativaCampos(true);
				txtCodigo.setEnabled(false);
			}
		});
		panel.add(btnAlterar);
		
		btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ctl.excluir(Integer.parseInt(txtCodigo.getText()));
				preencheCampos(ctl.getAtual());
				ativaCampos(false);
			}
		});
		panel.add(btnExcluir);
		
		btnAnt = new JButton("<");
		btnAnt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				preencheCampos(ctl.getAnt());
				ativaCampos(false);
			}
		});
		panel.add(btnAnt);
		
		btnProx = new JButton(">");
		btnProx.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				preencheCampos(ctl.getProx());
				ativaCampos(false);
			}
		});
		panel.add(btnProx);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(null);
		
		JLabel lblCdigo = new JLabel("Código:");
		lblCdigo.setBounds(12, 43, 70, 15);
		panel_1.add(lblCdigo);
		
		JLabel lblDescrio = new JLabel("Descrição:");
		lblDescrio.setBounds(12, 77, 92, 15);
		panel_1.add(lblDescrio);
		
		JLabel lblQuantidade = new JLabel("Quantidade:");
		lblQuantidade.setBounds(12, 110, 92, 15);
		panel_1.add(lblQuantidade);
		
		txtCodigo = new JTextField();
		txtCodigo.setBounds(122, 43, 200, 22);
		panel_1.add(txtCodigo);
		txtCodigo.setColumns(10);
		
		txtDescricao = new JTextField();
		txtDescricao.setBounds(122, 77, 200, 22);
		panel_1.add(txtDescricao);
		txtDescricao.setColumns(10);
		
		txtQtd = new JTextField();
		txtQtd.setBounds(122, 110, 200, 22);
		panel_1.add(txtQtd);
		txtQtd.setColumns(10);
		
		btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int codigo = ctl.salvar(preencheProduto(), 
											acao.equals("A"));
					txtCodigo.setText(Integer.toString(codigo));
					ativaCampos(false);
					acao = "";
				} catch (Exception e1) {
					System.out.println(e1.getMessage());
				}
			}
		});
		btnSalvar.setBounds(12, 157, 92, 25);
		panel_1.add(btnSalvar);
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ativaCampos(false);
				preencheCampos(ctl.getAtual());
				acao = "";
			}
		});
		btnCancelar.setBounds(117, 157, 96, 25);
		panel_1.add(btnCancelar);
		
		//Caso haja algum registro gravado, mostra o primeiro.
		if (ctl.temProx())
			preencheCampos(ctl.getProx());
		
		//Bloqueia os campos e ativa botões da barra de ferramentas.
		ativaCampos(false);
	}

	private void ativaCampos(boolean estadoAtivacao) {
		txtCodigo.setEnabled(estadoAtivacao);
		txtDescricao.setEnabled(estadoAtivacao);
		txtQtd.setEnabled(estadoAtivacao);
		btnSalvar.setVisible(estadoAtivacao);
		btnCancelar.setVisible(estadoAtivacao);
		
		btnIncluir.setEnabled(!estadoAtivacao);
		btnAlterar.setEnabled( (!estadoAtivacao) && (ctl.temAtual()) );
		btnExcluir.setEnabled( (!estadoAtivacao) && (ctl.temAtual()) );
		btnAnt.setEnabled( (!estadoAtivacao) && (ctl.temAnt()) );
		btnProx.setEnabled( (!estadoAtivacao) && (ctl.temProx()) );
	}
	
	private void preencheCampos(Produto p) {
		if (p == null) {
			txtCodigo.setText("");
			txtDescricao.setText("");
			txtQtd.setText("");
		} else {
			txtCodigo.setText(Integer.toString(p.getCodigo()));
			txtDescricao.setText(p.getDescricao());
			txtQtd.setText(Integer.toString(p.getQtd()));
		}
	}
	
	private Produto preencheProduto() throws Exception {
		//Prepara os dados.
		int codigo;
		String descricao;
		int qtd;

		try {
			codigo = Integer.parseInt(txtCodigo.getText().equals("") ? "0" : txtCodigo.getText());
		} catch (Exception e1) {
			throw new Exception("Favor digitar um código válido.");
		}
		descricao = txtDescricao.getText();
		try {
			qtd = Integer.parseInt(txtQtd.getText().equals("") ? "0" : txtQtd.getText()); 
		} catch (Exception e1) {
			throw new Exception("Favor digitar uma quantidade válida.");
		}

		Produto p = new Produto(codigo,	descricao, qtd);

		return p;
	}
	
	public JButton getBtnSalvar() {
		return btnSalvar;
	}
	public JButton getBtnCancelar() {
		return btnCancelar;
	}
	public JButton getBtnIncluir() {
		return btnIncluir;
	}
	public JButton getBtnAlterar() {
		return btnAlterar;
	}
	public JButton getBtnExcluir() {
		return btnExcluir;
	}
	public JButton getBtnAnt() {
		return btnAnt;
	}
	public JButton getBtnProx() {
		return btnProx;
	}
}

















