package br.com.elaborata;


public class Main {

	public static void main(String[] args) throws InterruptedException {
		long tempoIni = System.currentTimeMillis();

		ThreadPrimo t1 = new ThreadPrimo(1, 50000);
		ThreadPrimo t2 = new ThreadPrimo(50001, 100000);
		ThreadPrimo t3 = new ThreadPrimo(100001, 150000);
		ThreadPrimo t4 = new ThreadPrimo(150001, 200000);

		ThreadPrimo t5 = new ThreadPrimo(200001, 250000);
		ThreadPrimo t6 = new ThreadPrimo(250001, 300000);
		ThreadPrimo t7 = new ThreadPrimo(300001, 350000);
		ThreadPrimo t8 = new ThreadPrimo(350001, 400000);

		//Inicia todas as threads em processamento paralelo.
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		t6.start();
		t7.start();
		t8.start();
		
		//Espero todas as threads acabarem.
		t1.join();
		t2.join();
		t3.join();
		t4.join();
		t5.join();
		t6.join();
		t7.join();
		t8.join();
		
		System.out.println("Tempo total: " + 
		(System.currentTimeMillis() - tempoIni));
		
		System.out.println("Qtd. de primos: " +
				( t1.lst.size() + t2.lst.size() + 
				  t3.lst.size() + t4.lst.size() +
				  t5.lst.size() + t6.lst.size() +
				  t7.lst.size() + t8.lst.size() + 1
				)
				);
	}

}
