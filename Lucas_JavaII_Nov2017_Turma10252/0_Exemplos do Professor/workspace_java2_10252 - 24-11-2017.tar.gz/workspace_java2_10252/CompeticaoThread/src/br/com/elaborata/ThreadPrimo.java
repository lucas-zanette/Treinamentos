package br.com.elaborata;

import java.util.LinkedList;
import java.util.List;

public class ThreadPrimo extends Thread {

	private int ini, fin;
	public List<Integer> lst = new LinkedList<Integer>();
	
	public ThreadPrimo(int ini, int fin) {
		this.ini = ini;
		this.fin = fin;
	}
	
	public void run() {
		for (int i = ini; i <= fin; i++) {
			if (i % 2 != 0)
				if (isPrimo(i))
					lst.add(i);
		}
	}
	
	
	public boolean isPrimo(int n) {
		for (int i = 2; i < n; i++)
			if (n % i == 0)
				return false;
		return true;
	}
	
}


