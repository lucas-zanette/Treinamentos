import java.io.FileNotFoundException;

public class Main {

	public static void main(String[] args) {
		/*
		CriarArqTexto c = new CriarArqTexto();
		
		c.salvar(15, "Olá dia da batata!");
		c.salvar(20, "Bom dia.");
		c.fechar();
		 */
		
		AbrirArqTexto a = new AbrirArqTexto();
		try {
			a.executar();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
