import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class AbrirArqTexto {
	
	public void executar() throws FileNotFoundException {
		Scanner scanner = new Scanner(new File("/home/aluno/a.txt"));
	
		while (scanner.hasNext()) {
			System.out.println(scanner.nextLine());
		}
	}
}
