import java.io.FileNotFoundException;
import java.util.Formatter;

public class CriarArqTexto {
	private Formatter saida;
	String arquivo = "/home/aluno/exemplo.txt";
	
	public CriarArqTexto() {
		try {
			saida = new Formatter(arquivo);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void salvar(int codigo, String s) {
		saida.format("%d / %s\r\n", codigo, s);
		//saida.flush();
	}
	
	public void fechar() {
		saida.close();
	}
	
}
