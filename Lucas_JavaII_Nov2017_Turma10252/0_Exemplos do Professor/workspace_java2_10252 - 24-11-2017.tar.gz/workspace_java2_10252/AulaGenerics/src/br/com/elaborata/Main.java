package br.com.elaborata;

public class Main {

	public static void main(String[] args) {
		Integer[] inteiros = {4, 7, 2, 9, 5};
		Double[] reais = {5.5, 2.2, 7.7, 4.4, 1.1};
		String[] textos = {"a", "j", "k", "p", "b"};

		imprimir(inteiros);
		imprimir(reais);
		imprimir(textos);
		
	}

	public static <X> void imprimir(X[] l) {
		for (X i : l)
			System.out.println(i);
	}
	
	/*
	public static void imprimir(Integer[] l) {
		for (int i : l)
			System.out.println(i);
	}
	
	public static void imprimir(Double[] l) {
		for (double i : l)
			System.out.println(i);
	}

	public static void imprimir(String[] l) {
		for (String i : l)
			System.out.println(i);
	}
	*/
}
