package br.com.elaborata;

public class MainObjetoGenerico {

	public static void main(String[] args) {
		Controle<Pessoa> ctlP = new Controle<Pessoa>();
		Controle<Produto> ctlProd = new Controle<Produto>();
		
		Pessoa p = new Pessoa();
		p.setCod(1);
		p.setNome("Pedro");
		p.setEndereco("Rua P");
		ctlP.incluir(p);

		p = new Pessoa();
		p.setCod(2);
		p.setNome("Maria");
		p.setEndereco("Rua M");
		ctlP.incluir(p);
		
		p = new Pessoa();
		p.setCod(3);
		p.setNome("Luiz");
		p.setEndereco("Rua L");
		ctlP.incluir(p);

		ctlP.imprimir();
		
		Produto prod = new Produto();
		prod.setCod(10);
		prod.setDescricao("Geladeira");
		prod.setPreco(10.50);
		ctlProd.incluir(prod);

		prod = new Produto();
		prod.setCod(20);
		prod.setDescricao("Fogão");
		prod.setPreco(20.50);
		ctlProd.incluir(prod);
		
		prod = new Produto();
		prod.setCod(30);
		prod.setDescricao("Microondas");
		prod.setPreco(30.50);
		ctlProd.incluir(prod);
		
		ctlProd.imprimir();
	}

}
