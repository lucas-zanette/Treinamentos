package br.com.elaborata;

public class Pessoa {
	
	private int cod;
	private String nome;
	private String endereco;
	
	public int getCod() {
		return cod;
	}
	public void setCod(int cod) {
		this.cod = cod;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	//Gera o resultado que será dado quando este objeto
	//for convertido em texto. a função toString() é
	//default do java, e pode ser sobrescrita sempre
	//que necessário.
	public String toString() {
		return cod + ". " + nome + ", " + endereco;
	}
}
