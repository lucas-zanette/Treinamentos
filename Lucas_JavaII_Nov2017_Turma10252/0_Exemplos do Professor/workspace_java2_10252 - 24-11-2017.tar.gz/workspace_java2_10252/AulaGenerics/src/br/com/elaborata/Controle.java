package br.com.elaborata;

import java.util.ArrayList;
import java.util.List;

//O genérico K é um tipo genérico que será definido
//quando o objeto for criado.
public class Controle<K> {

	//Lista de objetos do tipo K, ou seja,
	//é uma lista de objetos do tipo que foi definido
	//quando o controle foi criado.
	List<K> lst;
	
	public Controle() {
		//Instancia a lista de objetos do tipo genérico K.
		lst = new ArrayList<K>();
	}
	
	public void incluir(K obj) {
		//Adiciona o objeto na lista.
		//O objeto é do tipo genérico, e a lista também. 
		lst.add(obj);
	}
	
	public void imprimir() {
		//Percorre todos os itens da lista.
		for (K k : lst)
			//Imprime o objeto diretamente, ou seja,
			//imprime o resultado da função toString();
			System.out.println(k);
	}
	
}
