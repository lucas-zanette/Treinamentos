package br.com.elaborata;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;

public class Main {

	/*
	public static void main(String[] args) {
		List<String> lstS = new ArrayList<String>();
		List<Integer> lstI = new LinkedList<Integer>();
		
		lstS.add("Teste5");
		lstS.add("Teste2");
		lstS.add("Teste2");
		lstS.add("Teste2");
		lstS.add("Teste2");
		lstS.add("Teste3");
		lstS.add("Teste2");
		lstS.add("Teste2");
		lstS.add("Teste2");
		lstS.add("Teste2");

		lstI.add(5);
		lstI.add(9);
		
		lstS.remove(5);
		
		for (int i = 0; i < lstS.size(); i++) {
			System.out.println(lstS.get(i));
		}
	}
*/
/*
	public static void main(String[] args) {
		List<Integer> lst = new ArrayList<Integer>();

		lst.add(5);
		lst.add(6);
		lst.add(7);
		lst.add(8);
		lst.add(9);
		lst.add(3);
		lst.add(34);
		lst.add(9);
		lst.add(76);
		lst.add(-5);

		int menor = Integer.MAX_VALUE;
		int pos = -1;
		
		for (int i = 0; i < lst.size(); i++) {
			if (lst.get(i) < menor) {
				menor = lst.get(i);
				pos = i;
			}
		}
		
		if (pos > -1) {
			lst.remove(pos);
		}
		
		for (Integer n : lst) 
			System.out.println(n);
	}
*/
	
	public static void main(String[] args) {
		/*
		List<String> a = new ArrayList<String>();
		List<String> b = new LinkedList<String>();
		
		Stack<Integer> stack = new Stack<Integer>();
		stack.push(1);
		stack.push(2);
		stack.push(3);
		stack.push(4);
		
		System.out.println(stack.pop());
		System.out.println(stack.pop());
		System.out.println(stack.peek());
		System.out.println(stack.pop());
		System.out.println(stack.pop());
		*/
		/*
		//Set<Integer> lst = new HashSet<Integer>();
		Set<Integer> lst = new LinkedHashSet<Integer>();
		
		lst.add(1);
		lst.add(1);
		lst.add(1);
		lst.add(2);
		lst.add(1);
		
		for (Integer i : lst)
			System.out.println(i);
		*/
		/*
		//TreeSet<Integer> lst = new TreeSet<Integer>();
		
		//Map<String, Integer> m = new HashMap<String, Integer>();
		//Map<String, Integer> m = new LinkedHashMap<String, Integer>();
		Map<String, Integer> m = new TreeMap<String, Integer>();

		m.put("Codigo", 2);
		m.put("Idade", 50);
		
		System.out.println(m.get("Idade"));
		*/
		
		List<String> lst = new ArrayList<String>();
		lst.add("Joaquim");
		lst.add("José");
		lst.add("Silva");
		lst.add("Xavier");
		lst.add("Tiradentes");

		/*
		 * Pig code detected.
		for (int i = 0; i < lst.size(); i++)
			System.out.println(lst.get(i));
		*/

		Collections.sort(lst);
		
		Collections.shuffle(lst);
		
		//Assim é o jeito certo de percorrer
		//a lista de forma sequencial.
		ListIterator<String> it = lst.listIterator();
		while (it.hasNext())
			System.out.println(it.next());
	}
	
}





























