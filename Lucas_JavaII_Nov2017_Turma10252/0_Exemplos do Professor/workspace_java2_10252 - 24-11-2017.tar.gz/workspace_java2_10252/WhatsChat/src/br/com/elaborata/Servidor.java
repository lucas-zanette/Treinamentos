package br.com.elaborata;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JTextArea;

public class Servidor extends Thread {
	JTextArea txtChat;

	public Servidor(JTextArea txtChat) {
		this.txtChat = txtChat;
		System.out.println("Criou o servidor.");
	}

	public void run() {
		try {
			while (true) {
				System.out.println("Aguarda uma conexão.");
				ServerSocket conexao;
				conexao = new ServerSocket(1234, 1);
				Socket cliente = conexao.accept();
	
				System.out.println("Conectou. Captura mensagem.");
				DataInputStream entrada = new DataInputStream(cliente.getInputStream());
				String msgEntrada = entrada.readUTF();
				
				System.out.println("Colocando mensagem na tela.");
				txtChat.setText(txtChat.getText() + "\n" +  msgEntrada);
	
				System.out.println("Fechando conexão.");
				entrada.close();
				cliente.close();
				conexao.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
