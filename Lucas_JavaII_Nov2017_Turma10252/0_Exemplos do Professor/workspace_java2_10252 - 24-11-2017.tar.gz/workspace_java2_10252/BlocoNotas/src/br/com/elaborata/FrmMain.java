package br.com.elaborata;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmMain extends JFrame {

	private CtlTexto ctl = new CtlTexto();
	
	private JPanel contentPane;
	private JTextField txtArq;
	private JTextArea txtTexto;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmMain frame = new FrmMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmMain() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 478, 288);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		panel.setLayout(new BorderLayout(0, 0));
		
		JLabel lblNewLabel = new JLabel("Arquivo:");
		panel.add(lblNewLabel, BorderLayout.WEST);
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1, BorderLayout.EAST);
		
		JButton btnAbrir = new JButton("Abrir");
		btnAbrir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					txtTexto.setText(ctl.abrir(txtArq.getText()));
				} catch (Exception e1) {
					System.out.println("Não foi possível abrir o arquivo.");
				}
			}
		});
		panel_1.add(btnAbrir);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					ctl.salvar(txtTexto.getText(), txtArq.getText());
				} catch (Exception e1) {
					System.out.println("Não foi possível salvar o arquivo.");
				}
			}
		});
		panel_1.add(btnSalvar);
		
		txtArq = new JTextField();
		panel.add(txtArq, BorderLayout.CENTER);
		txtArq.setColumns(10);
		
		txtTexto = new JTextArea();
		contentPane.add(txtTexto, BorderLayout.CENTER);
	}

	public JTextArea getTxtTexto() {
		return txtTexto;
	}
}
