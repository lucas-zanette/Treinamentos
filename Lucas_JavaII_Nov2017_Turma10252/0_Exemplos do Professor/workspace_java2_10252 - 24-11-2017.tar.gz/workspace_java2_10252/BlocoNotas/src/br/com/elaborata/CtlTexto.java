package br.com.elaborata;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.Scanner;

public class CtlTexto {

	public void salvar(String s, String arquivo) throws FileNotFoundException {
		//Crio um objeto para salvar texto.
		Formatter f = new Formatter(arquivo);
		
		//Descarrego o texto conforme a formatação definida no parâmetro.
		f.format("%s", s);

		//Fecho o arquivo.
		f.close();
	}
	
	public String abrir(String arquivo) throws Exception {
		//Crio um objeto que fará a leitura do texto.
		Scanner scanner = new Scanner(new File(arquivo));
		String s = "";
		
		//Enquanto houver alguma linha, captura linha a linha.
		while (scanner.hasNextLine()) {
			s = s + scanner.nextLine();
			
			if (scanner.hasNextLine())
				s = s + "\n";
		}

		//Fecho o arquivo.
		scanner.close();
		
		//Retorno o texto lido.
		return s;
	}
	
}
