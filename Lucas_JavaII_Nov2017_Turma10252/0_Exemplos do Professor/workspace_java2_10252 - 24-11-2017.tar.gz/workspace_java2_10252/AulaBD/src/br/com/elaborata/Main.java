package br.com.elaborata;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Main {

	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/aula?user=root&password=elaborata&useSSL=false");
		
		PreparedStatement pst = con.prepareStatement("insert into cliente (nome, salario) values (?, ?)");
		pst.setString(1, "Alpheu");
		pst.setDouble(2, 35000);
		pst.execute();
		
		PreparedStatement ps = con.prepareStatement("select * from cliente");
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			System.out.println(rs.getString("nome"));
		}
		
		con.close();
	}

}
