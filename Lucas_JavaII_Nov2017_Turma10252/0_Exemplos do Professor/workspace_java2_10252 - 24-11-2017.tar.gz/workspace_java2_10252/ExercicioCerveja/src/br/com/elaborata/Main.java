package br.com.elaborata;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		ArqBin ab = new ArqBin();
		ab.abrir("/home/aluno/ExemploCerveja.dat");
		ab.incluir(1, "BodeBrown", 5.35);
		ab.incluir(2, "WayBeer", 6.0);
		ab.incluir(3, "Klein", 7.5);
		ab.incluir(4, "Original", 4.30);
		ab.incluir(5, "Skol", 4.25);
		ab.exportar("/home/aluno/maior.txt", "/home/aluno/menor.txt");
		ab.fechar();
	}
}
