package br.com.elaborata;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class ArqBin {

	private final int tamReg = 52;
	RandomAccessFile f;

	public void abrir(String arq) throws FileNotFoundException {
		//Abro o arquivo para leitura e gravação.
		f = new RandomAccessFile(arq, "rw");
	}

	public void fechar() throws IOException {
		//Fecha o arquivo.
		f.close();		
	}

	public void incluir(int cod, String nome, double teor) throws IOException {
		//Salvo os campos.
		f.writeInt(cod); //4 bytes.
		f.writeChars(defineTamanho(nome, 20)); //40 bytes.
		f.writeDouble(teor); //8 bytes;
	}

	private String defineTamanho(String s, int tam) {
		//Vejo se tem caractere sobrando ou faltando.
		int dif = tam - s.length();
		
		//Se está faltando, adiciono espaços.
		if (dif > 0) {
			StringBuffer sb = new StringBuffer(tam);
			sb.append(s);
			while (dif > 0) {
				sb.append(' ');
				dif--;
			}
			return sb.toString();
		//Se está sobrando (ou está no tamanho exato),
		//pego apenas os caracteres que cabem no espaço
		//do campo.
		} else {
			return s.substring(0, tam);
		}
	}

	public void exportar(String arqMaior, String arqMenor) throws IOException {
		//Divide o tamanho do arquivo pelo tamanho de 
		//um registro, para descobrir quantos registros
		//o arquivo tem.
		long qtd = f.length() / tamReg;

		//Preparo os arquivos de destino.
		ArqTxt atMaior = new ArqTxt();
		ArqTxt atMenor = new ArqTxt();
		
		atMaior.abrir(arqMaior);
		atMenor.abrir(arqMenor);
		
		//Percorro todos os registros.
		for (int i = 1; i <= qtd; i++) {
			//Posiciono no início do registro.
			f.seek( (i - 1) * tamReg );
			
			//Leio todos os campos do registro.
			int cod = f.readInt();
			
			StringBuffer sb = new StringBuffer(20);
			for (int j = 0; j < 20; j++) {
				sb.append(f.readChar());
			}
			String nome = sb.toString().trim();
			
			double teor = f.readDouble();
			
			//Gravo os dados em um dos arquivos de destino.
			if (teor < 5) {
				atMenor.incluirLinha(cod + " - " + nome + " - " + teor + "\n");
			} else {
				atMaior.incluirLinha(cod + " - " + nome + " - " + teor + "\n");
			}
		}
		
		//Fecho os arquivos de destino.
		atMaior.fechar();
		atMenor.fechar();
	}

}





