package br.com.elaborata;

import java.io.FileNotFoundException;
import java.util.Formatter;

public class ArqTxt {

	Formatter f;
	
	public void abrir(String arq) throws FileNotFoundException {
		f = new Formatter(arq);		
	}

	public void fechar() {
		f.close();
	}

	public void incluirLinha(String s) {
		f.format("%s", s);
	}

}
