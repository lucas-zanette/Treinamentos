package br.com.elaborata;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JTextArea;

public class Servidor extends Thread {
	JTextArea txtChat;

	public Servidor(JTextArea txtChat) {
		this.txtChat = txtChat;
		System.out.println("Criou o servidor.");
	}

	public void run() {
		try {
			while (true) {
				DatagramSocket servidor = 
						new DatagramSocket(2345);

				DatagramPacket pacote = 
						new DatagramPacket(new byte[512],  512);
				servidor.receive(pacote);
				
				txtChat.setText(txtChat.getText() +
						"\n" +
						(new String(pacote.getData())));
				
				servidor.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
