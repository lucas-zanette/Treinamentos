package br.com.elaborata;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmChat extends JFrame {

	private JPanel contentPane;
	private JTextField txtMsg;
	private JTextField txtIp;
	private JTextField txtPorta;
	private JTextArea txtChat;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmChat frame = new FrmChat();
					frame.setVisible(true);
					
					Servidor servidor = new Servidor(frame.txtChat);
					servidor.start();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmChat() {
		System.out.println("Criando a janela.");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1, BorderLayout.NORTH);
		
		JLabel lblNewLabel = new JLabel("IP:");
		panel_1.add(lblNewLabel);
		
		txtIp = new JTextField();
		panel_1.add(txtIp);
		txtIp.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Porta:");
		panel_1.add(lblNewLabel_1);
		
		txtPorta = new JTextField();
		panel_1.add(txtPorta);
		txtPorta.setColumns(10);
		
		JPanel panel_2 = new JPanel();
		panel.add(panel_2, BorderLayout.SOUTH);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		JButton btnEnviar = new JButton("Enviar");
		btnEnviar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Cliente c = new Cliente();
				txtChat.setText(txtChat.getText() + 
						"\n" + 
						txtMsg.getText());
				c.enviar(txtIp.getText(), 
						Integer.parseInt(txtPorta.getText()), 
						txtMsg.getText());
			}
		});
		panel_2.add(btnEnviar, BorderLayout.EAST);
		
		txtMsg = new JTextField();
		panel_2.add(txtMsg, BorderLayout.CENTER);
		txtMsg.setColumns(10);
		
		txtChat = new JTextArea();
		txtChat.setEditable(false);
		contentPane.add(txtChat, BorderLayout.CENTER);
	}

	public JTextArea getTxtChat() {
		return txtChat;
	}
}
