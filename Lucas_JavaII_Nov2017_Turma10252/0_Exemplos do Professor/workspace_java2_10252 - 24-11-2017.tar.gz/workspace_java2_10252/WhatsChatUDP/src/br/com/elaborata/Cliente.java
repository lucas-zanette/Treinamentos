package br.com.elaborata;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Cliente {

	public void enviar(String ip, int porta, String msg) {
		try {
			DatagramSocket cliente = new DatagramSocket();
			InetAddress enderecoServidor = 
					InetAddress.getByName(ip);
			
			byte[] buffer = msg.getBytes();
			DatagramPacket pacote = 
					new DatagramPacket(buffer, 
							buffer.length, 
							enderecoServidor, 
							porta);
			cliente.send(pacote);
			System.out.println("Enviei: " + 
			(new String(pacote.getData())));
			
			cliente.close();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
