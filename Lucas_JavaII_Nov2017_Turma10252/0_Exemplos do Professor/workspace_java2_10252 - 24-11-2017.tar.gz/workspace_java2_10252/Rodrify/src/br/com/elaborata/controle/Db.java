package br.com.elaborata.controle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Db {

	private static Db db;
	private Connection con;
	
	private Db() { 
		//Construtor privado do design pattern Singleton.
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rodrify?user=root&password=elaborata&useSSL=false");
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | SQLException e) {
			System.out.println("Não foi possível conectar no banco de dados.");
			e.printStackTrace();
		}
	}
	
	public static Db getInstance() {
		if (db == null)
			db = new Db();
		
		return db;
	}
	
	public Connection getConnection() {
		return con;
	}
	
}
