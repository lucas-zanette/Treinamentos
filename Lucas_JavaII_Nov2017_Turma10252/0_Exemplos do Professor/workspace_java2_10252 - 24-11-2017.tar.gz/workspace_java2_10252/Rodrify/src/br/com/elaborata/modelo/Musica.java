package br.com.elaborata.modelo;

public class Musica {
	private int codigo;
	private String nome;
	private String autor;
	private String estilo;
	private int ano;
	
	public Musica(int codigo, String nome, String autor, String estilo, int ano) throws Exception {
		super();
		setCodigo(codigo);
		setNome(nome);
		setAutor(autor);
		setEstilo(estilo);
		setAno(ano);
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) throws Exception {
		if (codigo < 0)
			throw new Exception("O código não pode ser negativo.");
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) throws Exception {
		if ((nome == null) || (nome.equals("")))
			throw new Exception("O campo nome é obrigatório.");
		this.nome = nome;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) throws Exception {
		if ((autor == null) || (autor.equals("")))
			throw new Exception("O campo autor é obrigatório.");
		this.autor = autor;
	}
	public String getEstilo() {
		return estilo;
	}
	public void setEstilo(String estilo) throws Exception {
		if ((estilo == null) || (estilo.equals("")))
			throw new Exception("O campo estilo é obrigatório.");
		this.estilo = estilo;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) throws Exception {
		if (ano == 0)
			throw new Exception("O campo ano é obrigatório.");
		else if (ano < 0)
			throw new Exception("O campo ano não pode ser negativo.");
		this.ano = ano;
	}
}
