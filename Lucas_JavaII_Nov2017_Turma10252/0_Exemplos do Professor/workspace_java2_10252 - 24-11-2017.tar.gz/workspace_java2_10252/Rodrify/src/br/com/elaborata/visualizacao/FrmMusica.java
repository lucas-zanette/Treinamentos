package br.com.elaborata.visualizacao;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import br.com.elaborata.controle.Db;

import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class FrmMusica extends JFrame {

	private JPanel contentPane;
	private JTextField txtCodigo;
	private JTextField txtNome;
	private JTextField txtAutor;
	private JTextField txtEstilo;
	private JTextField txtAno;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		
		
		Db db = Db.getInstance();

		db.getConnection().prepareStatement(sql)
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmMusica frame = new FrmMusica();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FrmMusica() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 640, 333);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_2 = new JPanel();
		panel.add(panel_2, BorderLayout.EAST);
		
		JButton btnSalvar = new JButton("Salvar");
		panel_2.add(btnSalvar);
		
		JButton btnCancelar = new JButton("Cancelar");
		panel_2.add(btnCancelar);
		
		JPanel panel_3 = new JPanel();
		panel.add(panel_3, BorderLayout.CENTER);
		panel_3.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
		
		JButton btnIncluir = new JButton("Incluir");
		panel_3.add(btnIncluir);
		
		JButton btnAlterar = new JButton("Alterar");
		panel_3.add(btnAlterar);
		
		JButton btnExcluir = new JButton("Excluir");
		panel_3.add(btnExcluir);
		
		JButton btnAnt = new JButton("<");
		panel_3.add(btnAnt);
		
		JButton btnProx = new JButton(">");
		panel_3.add(btnProx);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Código:");
		lblNewLabel.setBounds(30, 34, 70, 15);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nome:");
		lblNewLabel_1.setBounds(30, 76, 70, 15);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Autor:");
		lblNewLabel_2.setBounds(30, 116, 70, 15);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Estilo:");
		lblNewLabel_3.setBounds(30, 158, 70, 15);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Ano:");
		lblNewLabel_4.setBounds(30, 199, 70, 15);
		panel_1.add(lblNewLabel_4);
		
		txtCodigo = new JTextField();
		txtCodigo.setBounds(134, 32, 58, 19);
		panel_1.add(txtCodigo);
		txtCodigo.setColumns(10);
		
		txtNome = new JTextField();
		txtNome.setBounds(134, 74, 481, 19);
		panel_1.add(txtNome);
		txtNome.setColumns(10);
		
		txtAutor = new JTextField();
		txtAutor.setBounds(134, 114, 481, 19);
		panel_1.add(txtAutor);
		txtAutor.setColumns(10);
		
		txtEstilo = new JTextField();
		txtEstilo.setBounds(134, 156, 229, 19);
		panel_1.add(txtEstilo);
		txtEstilo.setColumns(10);
		
		txtAno = new JTextField();
		txtAno.setBounds(134, 199, 58, 19);
		panel_1.add(txtAno);
		txtAno.setColumns(10);
	}
}
