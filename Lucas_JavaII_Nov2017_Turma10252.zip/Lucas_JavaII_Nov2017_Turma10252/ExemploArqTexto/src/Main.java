
public class Main {

	public static void main(String[] args) {
		CriarArqTexto c = new CriarArqTexto();
		
			c.salvar(15, "Olá dia da batata!");
			c.salvar(20, "Tem pão de queijo!");
			c.fechar();
	}

}
