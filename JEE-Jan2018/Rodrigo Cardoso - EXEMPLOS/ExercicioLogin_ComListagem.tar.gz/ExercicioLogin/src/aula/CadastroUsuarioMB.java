package aula;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class CadastroUsuarioMB {
	private Usuario usuario = new Usuario();

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	
	//Salva o usuário e redireciona a página.
	public String salvar() {
		try {
			Connection con = Biblioteca.getConnection();
			String sql = "insert into usuario (nome, login, senha) values (?, ?, md5(?))";
			Biblioteca.execSql(con, sql, usuario.getNome(), usuario.getLogin(), usuario.getSenha());
			con.close();
			return "/pages/TelaPrincipal";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public List<Usuario> getLista() {
		try {
			Connection con = Biblioteca.getConnection();
			String sql = "select * from usuario";
			ResultSet rs = Biblioteca.execSql(con, sql);
			
			List<Usuario> lst = new ArrayList<Usuario>();
			while (rs.next()) {
				Usuario u = new Usuario();
				u.setCodigo(rs.getInt("codigo"));
				u.setNome(rs.getString("nome"));
				u.setLogin(rs.getString("login"));
				lst.add(u);
			}
			
			con.close();
			return lst;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
